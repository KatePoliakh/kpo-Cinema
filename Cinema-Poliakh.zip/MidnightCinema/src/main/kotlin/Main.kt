import domain.CinemaController
import domain.entity.Cinema
import domain.entity.Hall
import domain.CinemaControllerImpl
import domain.CinemaHall
import domain.entity.Movie
import java.time.LocalDateTime

fun main() {
    val hall = CinemaHall(10, 10)
    val cinema = CinemaControllerImpl("MidnightCinema", hall)
    while (true) {
        println("\n=== Cinema Management System ===")
        println("1. Sell Ticket")
        println("2. Return Ticket")
        println("3. Display Available Seats")
        println("4. Edit Movie Data")
        println("5. Edit Session Schedule")
        println("6. Mark Visitors for Session")
        println("7. Save Data")
        println("8. Load Data")
        println("0. Exit")

        print("Enter your choice: ")
        when (readLine()?.toIntOrNull() ?: -1) {
            1 -> sellTicket(cinema)
            //2 -> returnTicket(cinema)
            3 -> displayAvailableSeats(cinema)
            4 -> addNewMovie(cinema)
            //4 -> editMovieData(cinema)
            //5 -> editSessionSchedule(cinema)
            //6 -> markVisitors(cinema)
            //7 -> cinema.saveData()
            //8 -> cinema.loadData()
            0 -> {
                println("Exiting the Cinema Management System. Goodbye!")
                return
            }

            else -> println("Invalid choice. Please enter a valid option.")
        }
    }
}

fun sellTicket(cinemaController: CinemaControllerImpl) {
    println("=== Sell Ticket ===")

    println("Available Movies:")
    cinemaController.displayMovies()

    print("Enter the movie title: ")
    val movieTitle = readLine() ?: ""

    if (!cinemaController.isMovieAvailable(movieTitle)) {
        println("Error: The entered movie is not available. Returning to the main menu.")
        return
    }
    val movie = cinemaController.getMovieByTitle(movieTitle)

    print("Enter the session time (yyyy-MM-dd HH:mm): ")
    val sessionTimeStr = readLine() ?: ""
    val sessionTime = try {
        LocalDateTime.parse(sessionTimeStr)
    } catch (e: Exception) {
        println("Invalid date-time format. Returning to main menu.")
        return
    }

    println("Available Seats:")
    cinemaController.displayAvailableSeats(movieTitle, sessionTime)

    print("Enter the seat row: ")
    val seatRow = readLine()?.toIntOrNull() ?: -1

    print("Enter the seat number: ")
    val seatNumber = readLine()?.toIntOrNull() ?: -1


    val success = cinemaController.sellTicket(movie, sessionTime, seatRow, seatNumber)

    if (success) {
        println("Ticket sold successfully!")
    } else {
        println("Error: Unable to sell the ticket.")
    }
}

fun returnTicket(cinemaController: CinemaController, movieTitle: String) {
    println("=== Return Ticket ===")

    try {
        // Retrieve the movie from the list
        val movie = cinemaController.getMovieByTitle(movieTitle)

        // Prompt user to enter the session time
        print("Enter the session time (yyyy-MM-dd HH:mm): ")
        val sessionTimeStr = readLine() ?: ""
        val sessionTime = try {
            LocalDateTime.parse(sessionTimeStr)
        } catch (e: Exception) {
            println("Invalid date-time format. Returning to the main menu.")
            return
        }

        // Prompt user to enter the seat details
        print("Enter the seat row: ")
        val seatRow = readLine()?.toIntOrNull() ?: -1

        print("Enter the seat number: ")
        val seatNumber = readLine()?.toIntOrNull() ?: -1

        // Return the ticket
        val success = cinemaController.refundTicket(movieTitle, sessionTime, seatRow, seatNumber)

        if (success) {
            println("Ticket returned successfully!")
        } else {
            println("Error: Unable to return the ticket.")
        }
    } catch (e: NoSuchElementException) {
        println("Error: ${e.message}")
        println("Returning to the main menu.")
    }
}

fun displayAvailableSeats(cinemaController: CinemaController) {
    println("=== Display Available Seats ===")

    print("Enter the movie title: ")
    val movieTitle = readLine() ?: ""

    print("Enter the session time (yyyy-MM-dd HH:mm): ")
    val sessionTimeStr = readLine() ?: ""
    val sessionTime = try {
        LocalDateTime.parse(sessionTimeStr)
    } catch (e: Exception) {
        println("Invalid date-time format. Returning to the main menu.")
        return
    }

    cinemaController.displayAvailableSeats(movieTitle, sessionTime)
}
fun addNewMovie(cinemaController: CinemaController) {
    println("=== Add New Movie ===")

    print("Enter the movie title: ")
    val title = readLine() ?: ""

    print("Enter the movie genre: ")
    val genre = readLine() ?: ""

    print("Enter the movie duration (in minutes): ")
    val duration = readLine()?.toIntOrNull() ?: 0

    print("Enter the session time (yyyy-MM-dd HH:mm): ")
    val sessionTimeStr = readLine() ?: ""
    val sessionTime = try {
        LocalDateTime.parse(sessionTimeStr)
    } catch (e: Exception) {
        println("Invalid date-time format. Returning to the main menu.")
        return
    }

    val newMovie = Movie(title, duration)
    cinemaController.addMovie(newMovie)
}