package dao

interface RuntimeMovieDao {
}