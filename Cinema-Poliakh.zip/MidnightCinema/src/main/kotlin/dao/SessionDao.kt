package dao

interface SessionDao {
}