package dao

import domain.entity.Movie
import java.util.*

interface MovieDao {
    //fun getAllMovies(): List<MovieOutput>
    //fun getMovieById(movieId: Int): MovieOutput
    //fun addMovie(newMovieData:    ): Result<String>
    fun deleteFilm(movieId: Int): Result<String>
    fun editFilmTitle(movieId: Int, newTitle: String): Result<String>


    fun getAll(): List<Movie>
    fun getById(id: UUID): Movie
    fun getByTitle(title: String): Movie
    //fun add(item: FilmAddEntity)
    //fun update(id: UUID, item: FilmUpdateEntity)
    fun delete(id: UUID)
}