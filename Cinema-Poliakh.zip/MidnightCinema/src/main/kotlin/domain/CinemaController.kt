package domain

import domain.entity.Movie
import domain.entity.Session
import domain.entity.Ticket
import java.time.LocalDateTime

interface CinemaController {
    fun addMovie(movie: Movie)
    fun createSession(movie: Movie, time: LocalDateTime)
    fun sellTicket(movie: Movie, time: LocalDateTime, seatRow: Int, seatNumber: Int): Boolean
    fun refundTicket(movieTitle: String, sessionTime: LocalDateTime, seatRow: Int, seatNumber: Int): Boolean
    fun displayAvailableSeats(title: String, time: LocalDateTime)
    fun displayMovies()
    fun isMovieAvailable(movieTitle: String): Boolean
    fun getMovieByTitle(title: String): Movie
    fun editMovieData(movieTitle: String)
}

class CinemaControllerImpl(
    private val name: String,
    private val hall: CinemaHall,
    private val movies: MutableList<Movie> = mutableListOf(),
    private val sessions: MutableMap<LocalDateTime, Session> = mutableMapOf(),
    private val movieValidator: MovieValidator = MovieValidatorImpl(),
    private val sessionValidator: SessionValidator = SessionValidatorImpl()
) : CinemaController {
    override fun addMovie(movie: Movie) {
        if (movieValidator.validateMovieDetails(movie.title, movie.durationMinutes)) {
            movies.add(movie)
        } else {
            println("Error: Invalid movie details.")
        }
    }

    override fun createSession(movie: Movie, time: LocalDateTime) {
        if (movies.contains(movie) && sessionValidator.validateSessionDetails(movie, time)) {
            sessions[time] = Session(movie, time, sessionValidator)
            println("Session created successfully.")
        } else {
            println("Error: Invalid session details.")
        }
    }

    override fun sellTicket(movie: Movie, sessionTime: LocalDateTime, seatRow: Int, seatNumber: Int): Boolean {
        if (sessions.containsKey(sessionTime)) {
            val sessionData = sessions[sessionTime]
            if (sessionData != null) {
                val sessionController = SessionControllerImpl(sessionData.movie,sessionData.time, sessionValidator,hall)
                return sessionController.sellTicket(seatRow, seatNumber)
            } else {
                println("Error: Session data is null.")
                return false
            }
        } else {
            println("Error: Session not found.")
            return false
        }
        return true
    }

    override fun refundTicket(movieTitle: String, sessionTime: LocalDateTime, seatRow: Int, seatNumber: Int): Boolean {
        val sessionData = sessions[sessionTime]

        if (sessionData == null || isSessionStarted(sessionTime)) {
            println("Error: Cannot refund this ticket.")
            return false
        }

       /* val ticket = sessionData.tickets.find {
            it.movie.title.equals(movieTitle, ignoreCase = true) &&
                    it.seatRow == seatRow &&
                    it.seatNumber == seatNumber
        }

        if (ticket == null || ticket.isRefunded) {
            println("Error: Cannot refund this ticket.")
            return false
        }*/

        //ticket.isRefunded = true
        hall.markSeatAsVacant(seatRow, seatNumber)
        println("Ticket refunded successfully.")
        return true
    }

    override fun displayAvailableSeats(title: String,time: LocalDateTime) {
        if (sessions.containsKey(time)) {
            hall.displayAvailableSeats()
        } else {
            println("Error: Session not found.")
        }
    }

    override fun displayMovies() {
        println("Movies currently in the cinema:")
        movies.forEach { println("${it.title} - ${it.durationMinutes} minutes") }
    }


    override fun isMovieAvailable(movieTitle: String): Boolean {
        return movies.any { it.title.equals(movieTitle, ignoreCase = true) }
    }

    override fun getMovieByTitle(title: String): Movie {
        return movies.find { it.title.equals(title, ignoreCase = true) }
            ?: throw NoSuchElementException("Movie with title $title not found.")
    }
    private fun isSessionStarted(time: LocalDateTime): Boolean {
        // Implement logic to check if the session has started
        return false
    }

    override fun editMovieData(movieTitle: String) {
        val movie = movies.find { it.title.equals(movieTitle, ignoreCase = true) }

        if (movie == null) {
            println("Error: Movie with title '$movieTitle' not found.")
            return
        }

        println("Editing Movie Data for: $movieTitle")
        println("1. Edit Movie Title")
        println("2. Edit Movie Duration")
        println("0. Cancel")

        print("Enter your choice: ")
        when (readLine()?.toIntOrNull() ?: -1) {
            1 -> {
                print("Enter new movie title: ")
                val newTitle = readLine() ?: ""
                //movie.editMovieData(newTitle)
                println("Movie title updated successfully.")
            }
            2 -> {
                print("Enter new movie duration (in minutes): ")
                val newDuration = readLine()?.toIntOrNull() ?: 0
              //  movie.durationMinutes = newDuration
                println("Movie duration updated successfully.")
            }
            0 -> {
                println("Canceling the edit.")
                return
            }
            else -> println("Invalid choice. Please enter a valid option.")
        }
    }

}

