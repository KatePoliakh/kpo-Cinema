package domain

interface MovieValidator {
    fun validateMovieDetails(title: String, durationMinutes: Int): Boolean
}

class MovieValidatorImpl : MovieValidator {
    override fun validateMovieDetails(title: String, durationMinutes: Int): Boolean {
        return title.isNotBlank() && durationMinutes > 0
    }
}
