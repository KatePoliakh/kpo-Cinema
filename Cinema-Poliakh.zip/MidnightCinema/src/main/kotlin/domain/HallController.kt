package domain

class CinemaHall(
    val rows: Int = 10,
    val seatsPerRow: Int = 10
) {
    val seats: Array<Array<Boolean>> = Array(rows) { Array(seatsPerRow) { false } }

    fun markSeatAsOccupied(row: Int, seatNumber: Int) {
        seats[row - 1][seatNumber - 1] = true
    }

    fun isSeatOccupied(row: Int, seatNumber: Int): Boolean {
        return seats[row - 1][seatNumber - 1]
    }

    fun displayAvailableSeats() {
        for (i in 1..rows) {
            for (j in 1..seatsPerRow) {
                print(if (seats[i - 1][j - 1]) "X " else "O ")
            }
            println()
        }
    }

    fun markSeatAsVacant(row: Int, seatNumber: Int) {
        if (isValidSeat(row, seatNumber)) {
            seats[row - 1][seatNumber - 1] = false
        } else {
            println("Error: Invalid seat.")
        }
    }

    fun isValidSeat(row: Int, seatNumber: Int): Boolean {
        return row in 1..rows && seatNumber in 1..seatsPerRow
    }
}
