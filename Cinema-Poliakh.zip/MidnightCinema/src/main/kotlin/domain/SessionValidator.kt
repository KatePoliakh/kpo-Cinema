package domain

import domain.entity.Movie
import domain.MovieValidator
import java.time.LocalDateTime


interface SessionValidator {
    fun validateSessionDetails(movie: Movie, time: LocalDateTime): Boolean
}
class SessionValidatorImpl (private val movieValidator: MovieValidator = MovieValidatorImpl()) :SessionValidator{
    override fun validateSessionDetails(movie: Movie, time: LocalDateTime): Boolean {
        return /*time. &&*/ isValidMovie(movie)
    }

    private fun isValidMovie(movie: Movie): Boolean {
        return movieValidator.validateMovieDetails(movie.title, movie.durationMinutes)
    }
}