package domain.entity

data class Hall(
    val row: Int,
    val seats: Int,
)
