package domain.entity

import domain.CinemaHall
import domain.SessionValidator
import java.time.LocalDateTime

data class Session(
    val movie: Movie,
    val time: LocalDateTime,
    val sessionValidator: SessionValidator,
    //val tickets: List<Ticket>
    //val movieId: Int,
    //val dateTime: LocalDateTime,
    //val ticketPrice: Double,
    //val seats: List<List<SeatState>>,
)