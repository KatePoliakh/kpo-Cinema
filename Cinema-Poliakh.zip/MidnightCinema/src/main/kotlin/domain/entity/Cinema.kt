package domain.entity

data class Cinema(
    val name: String,
    val hall: Hall,
)
