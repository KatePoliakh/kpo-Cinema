package domain.entity

data class Movie(
    val title: String,
    val durationMinutes: Int,
)
