package domain.entity
import java.time.LocalDateTime

data class Ticket(
    val movie: Movie,
    val sessionTime: LocalDateTime,
    val seatRow: Int,
    val seatNumber: Int,
    var isRefunded: Boolean = false
)

