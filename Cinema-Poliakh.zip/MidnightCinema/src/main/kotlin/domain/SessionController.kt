package domain

import domain.entity.Hall
import domain.entity.Movie
import domain.entity.Session
import java.time.LocalDateTime


interface SessionController {
    fun displaySessionDetails()
    fun sellTicket(seatRow: Int, seatNumber: Int): Boolean
}
class SessionControllerImpl(
    private val movie: Movie,
    private val time: LocalDateTime,
    //private val tickets: MutableList<Ticket>,
    private val sessionValidator: SessionValidator = SessionValidatorImpl(),
    private val hall: CinemaHall,
) : SessionController {

    override fun displaySessionDetails() {
        println("Session Details:")
        println("Movie: ${movie}")
        println("Time: $time")
    }

    override fun sellTicket(seatRow: Int, seatNumber: Int): Boolean {
        if (!sessionValidator.validateSessionDetails(movie, time)) {
            println("Error: Invalid session details.")
            return false
        }

        if (!hall.isValidSeat(seatRow, seatNumber)) {
            println("Error: Invalid seat.")
            return false
        }

        if (hall.isSeatOccupied(seatRow, seatNumber)) {
            println("Error: Seat already occupied.")
            return false
        }

        // Mark seat as occupied
        hall.markSeatAsOccupied(seatRow, seatNumber)

        // Display sold ticket details
        println("Ticket sold successfully:")
        println("Movie: ${movie.title}")
        println("Time: ${time}")
        println("Seat: Row $seatRow, Seat $seatNumber")

        return true
    }


}
