package domain

class ffgfgfgfgf {
}