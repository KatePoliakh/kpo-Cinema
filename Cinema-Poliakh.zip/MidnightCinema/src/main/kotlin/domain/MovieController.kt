package domain


interface MovieController {
    fun changeTitle(newTitle: String)
    fun changeDuration(newDurationMinutes: Int)
    fun displayMovieDetails()
}
class MovieControllerImpl(
    var title: String,
    var durationMinutes: Int
) : MovieController {

    override fun changeTitle(newTitle: String) {
        this.title = newTitle
    }

    override fun changeDuration(newDurationMinutes: Int) {
        this.durationMinutes = newDurationMinutes
    }

    override fun displayMovieDetails() {
        println("Movie Details:")
        println("Title: $title")
        println("Duration: $durationMinutes minutes")
    }
}