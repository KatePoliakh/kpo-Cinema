package presentation.output

data class MovieOutput(
    val title: String,
    val durationMinutes: Int,
)
