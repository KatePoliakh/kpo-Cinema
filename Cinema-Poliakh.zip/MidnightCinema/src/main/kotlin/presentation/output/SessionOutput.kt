package presentation.output

import domain.SessionValidator
import domain.entity.Movie
import java.time.LocalDateTime

data class SessionOutput(
    val movie: Movie,
    val time: LocalDateTime,
    val sessionValidator: SessionValidator,
)

