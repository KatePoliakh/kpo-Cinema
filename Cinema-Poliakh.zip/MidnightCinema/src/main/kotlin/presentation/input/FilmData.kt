package presentation.input

data class FilmData(
    val title: String,

)
